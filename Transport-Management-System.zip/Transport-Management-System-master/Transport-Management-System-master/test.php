<?php 

echo date(1)."-".date("m")."-".date("Y");
// ECHO ' <br/>'; 
// echo jddayofweek ( cal_to_jd(CAL_GREGORIAN, date("m"),date(1), date("Y")) , 1 );
?>